<?php

use yii\db\Migration;

/**
 * Class m180515_062329_test
 */
class m180515_062329_test extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {

    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m180515_062329_test cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m180515_062329_test cannot be reverted.\n";

        return false;
    }
    */
}
